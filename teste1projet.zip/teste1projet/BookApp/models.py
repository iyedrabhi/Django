from django.db import models
from django.core.validators import MinLengthValidator
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
#from ConferenceApp.models import Conference
# Create your models here.
class Book(models.Model):
    book_id=models.AutoField(primary_key=True) #############autofield wala increment mouch kima user PK CIN
    title=models.CharField(max_length=50)
    author=models.CharField(max_length=50)
    book_file=models.CharField(max_length=100)
    publication_date = models.DateField()
    created_at=models.DateTimeField(null=True)
    updated_at=models.DateTimeField(null=True)
    def __str__(self):
        return f"{self.title} - {self.author} -{self.book_file}"
    category=models.ForeignKey("CategoryApp.Category",on_delete=models.CASCADE,related_name="categories")

import uuid

class Borrowing(models.Model):
    borrowing_id = models.CharField(
        primary_key=True,
        max_length=50,
        unique=True,
        editable=False,
        default=uuid.uuid4  # ✅ auto-génère un identifiant unique
    )
    library_identifier = models.ForeignKey("ClientApp.Client", on_delete=models.CASCADE, related_name="borrowings")
    book = models.ForeignKey("BookApp.Book", on_delete=models.CASCADE, related_name="borrowings")
    borrowing_date = models.DateField(auto_now_add=True)
    returned = models.BooleanField(default=False)
    return_date = models.DateField(auto_now_add=True)
    def clean(self):
        if self.borrowing_date >= self.return_date :
            raise ValidationError("la date retour doit etre posterieure")

