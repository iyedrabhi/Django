from django.db import models
from django.contrib.auth.models import AbstractUser ########Bech tjib abstractuser 7adher
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator

# Create your models here.
import uuid
def generate_userid():
    return "USER"+uuid.uuid4().hex[:4].upper()
def verify_email(email):
    domaine=["gmail.com"]
    if email.split("@")[1] not in domaine:
        raise ValidationError("l'email est invalide et appartenir a un domaine universitaire")
    
name_validator = RegexValidator (
    regex=r'^[A-Za-z\s-]+$' ####### EXPRESSION REGULIER regex=r'[A-Za-z\s-]+' MATEMCHICH FOR SOME REASON
)
    

class Client(AbstractUser):
    library_identifier=models.CharField(max_length=8,primary_key=True,unique=True,editable=False)
    user_name=models.CharField(max_length=50,validators=[name_validator],unique=True)
    first_name=models.CharField(max_length=50,validators=[name_validator])
    last_name=models.CharField(max_length=50,validators=[name_validator])
    email=models.EmailField(unique=True,validators=[verify_email])
    created_at=models.DateTimeField(null=True)
    updated_at=models.DateTimeField(null=True)
    
    def save(self,*args,**kwargs):###########Fonc save tbadel fel user#args kif nabda manaarech number args, ki yabda andi args bel cle..
        if not self.user_id:
            new_id=generate_userid()
            while Client.objects.filter(library_identifier=new_id).exists():
                new_id=generate_userid()
            self.user_id=new_id
        super().save(*args,**kwargs)