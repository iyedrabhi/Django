from django.contrib import admin
from .models import ClientApp
# Register your models here.
admin.site.register(ClientApp)
