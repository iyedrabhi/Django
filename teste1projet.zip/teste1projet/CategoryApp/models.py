from django.db import models
from django.core.validators import MinLengthValidator
from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
#from ConferenceApp.models import Conference
# Create your models here.
    
class Category(models.Model):
    category_id=models.AutoField(primary_key=True) #############autofield wala increment mouch kima user PK CIN
    category_name=models.CharField(max_length=50)
    
    created_at=models.DateTimeField(null=True)
    updated_at=models.DateTimeField(null=True)
    def __str__(self):
        return f"{self.category_name}"
    